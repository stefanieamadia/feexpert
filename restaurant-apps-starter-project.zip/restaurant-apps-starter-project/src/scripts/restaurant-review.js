// import restaurantSource from "./restaurant-source";
// import { createReviewRestaurant } from "./templates-creator";

// const ReviewRestaurant = {
//     async render() {
//         return `
//             <h1 class="list-resto">Testimoni</h1>
//         `;
//     },

//     async afterRender() {
//         const review = await restaurantSource.rerviewRestaurant();
//         console.log(review);
//         const reviewContaint = document.querySelector('#testimoni');
//         review.forEach((review) => {
//             reviewContaint.innerHTML += createReviewRestaurant(review);
//         });
//     }
// }

// export default ReviewRestaurant;