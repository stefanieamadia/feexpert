import API_ENDPOINT from "./config/api-endpoint";

class restaurantSource {
    static async listRestaurant() {
        const response = await fetch(API_ENDPOINT.LIST_RESTAURANT);
        return response.json();
    }

    static async detailRestaurant(id) {
        const response = await fetch(API_ENDPOINT.DETAIL(id));
        return response.json();
    }

    static async rerviewRestaurant() {
        const response = await fetch(API_ENDPOINT.POTS_REVIEW, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });
            return response.json();
        }
}

export default restaurantSource;