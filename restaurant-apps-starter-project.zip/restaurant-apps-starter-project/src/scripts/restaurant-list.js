import restaurantSource from "./restaurant-source";
import { createListRestaurant } from "./templates-creator";

const ListRestaurant = {
    async render() {
        return `
            <h1 class="list-resto" id="maincontent">List Restaurant</h1>
            <section class="catalog-card" id="restaurant"><section>
        `;
    },

    async afterRender() {
        const restaurant = await restaurantSource.listRestaurant();
        console.log(restaurant);
        const restaurantContaint = document.querySelector('#listresturant');
        restaurant.forEach((restaurant) => {
            restaurantContaint.innerHTML += createListRestaurant(restaurant);
        });
    },
};

export default ListRestaurant;