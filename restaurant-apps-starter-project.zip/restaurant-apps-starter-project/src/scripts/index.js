import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
// import data from '../public/data/DATA.json';

// console.log(data.restaurants);

const toggleButton = document.getElementById("toggle-button");
const navMenu = document.getElementById("navig-menu");

const toggleRead = document.getElementById("desc-resto");
const descBut = document.getElementById("desc-button");

toggleButton.addEventListener('click', () =>{
    navMenu.classList.toggle('active');
})

// console.log(data.restaurants[2]['pictureId']);

// // Card 1
// const imgSrc1 = data.restaurants[1]['pictureId'];
// const ratIng1 = data.restaurants[1]['rating'];
// const name1 = data.restaurants[1]['name'];
// const kota1 = data.restaurants[1]['city'];
// const descP1 = data.restaurants[1]['description'];;

// document.getElementById("img-resto").src = imgSrc1;
// document.getElementById("img-resto").alt = name1;
// document.getElementById("rating-resto").innerText = ratIng1;
// document.getElementById("nama-resto").innerText = name1;
// document.getElementById("kota-resto").innerText = kota1;
// document.getElementById("desc-resto").innerText = descP1;

// // card 2
// const imgSrc2 = data.restaurants[2]['pictureId'];
// const ratIng2 = data.restaurants[2]['rating'];
// const name2 = data.restaurants[2]['name'];
// const kota2 = data.restaurants[2]['city'];
// const descP2 = data.restaurants[2]['description'];;

// document.getElementById("img-resto2").src = imgSrc2;
// document.getElementById("img-resto2").alt = name2;
// document.getElementById("rating-resto2").innerText = ratIng2;
// document.getElementById("nama-resto2").innerText = name2;
// document.getElementById("kota-resto2").innerText = kota2;
// document.getElementById("desc-resto2").innerText = descP2;

// // card 2
// const imgSrc3 = data.restaurants[3]['pictureId'];
// const ratIng3 = data.restaurants[3]['rating'];
// const name3 = data.restaurants[3]['name'];
// const kota3 = data.restaurants[3]['city'];
// const descP3 = data.restaurants[3]['description'];

// document.getElementById("img-resto3").src = imgSrc3;
// document.getElementById("img-resto3").alt = name3;
// document.getElementById("rating-resto3").innerText = ratIng3;
// document.getElementById("nama-resto3").innerText = name3;
// document.getElementById("kota-resto3").innerText = kota3;
// document.getElementById("desc-resto3").innerText = descP3;

// fetch('./data/DATA.json')
//     .then(function (response){
//         return response.json();
//     })
//     .then((responseJson) => {
//         const conText = responseJson;
//         const text = JSON.stringify(responseJson);
//         const text2 = JSON.parse(text);
//         console.log(conText[5]);
//     })