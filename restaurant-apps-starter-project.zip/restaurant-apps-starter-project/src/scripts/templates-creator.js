import CONFIG from "./config/config";

const createListRestaurant = (restaurant) => `
    <section class="catalog-card" id="listresturant">
    <section class="card">
    <img id="img-resto" src="${CONFIG.BASE_IMAGE_URL + restaurant.pictureId}" alt>
    <h5>Rating</h5><h5 id="rating-resto">${restaurant.rating}</h5>
    <h3 id="nama-resto">${restaurant.name}</h3>
    <h4 id="kota-resto">${restaurant.city}</h4>
    <p id="desc-resto" class="collapse-parap">${restaurant.description}</p>
    <button type="button" class="collapse" id="desc-button"
        onclick="return ">
        Description
    </button>
    </section>
`;

const createReviewRestaurant = (restaurant) => `
    <section class="catalog-card" id="testimoni">
    <section class="card-testimoni">
    <img src="./images/testimoni/pexels-andrea-piacquadio-733872.jpg"
        alt>
    <h3></h3>
    <p></p>
    </section>
    <section class="card-testimoni">
    <img src="./images/testimoni/pexels-daniel-xavier-1239291.jpg" alt>
    <h3></h3>
    <p></p>
    </section>
    <section class="card-testimoni">
    <img src="./images/testimoni/pexels-justin-shaifer-1222271.jpg" alt>
    <h3></h3>
    <p></p>
    </section>
    </section>
`;

const createUnlikeMovieButtonTemplate = () => `
  <button aria-label="like this resto" id="likeButton" class="like">
  <i class="fa fa-heart-o" aria-hidden="true"></i>
  </button>
`;

const createLikedButtonTemplate = () => `
  <button aria-label="unlike this resto" id="likeButton" class="like">
    <i class="fa fa-heart with" aria-hidden="true"></i>
  </button>
`;

export {createListRestaurant, createReviewRestaurant, createUnlikeMovieButtonTemplate, createLikedButtonTemplate};